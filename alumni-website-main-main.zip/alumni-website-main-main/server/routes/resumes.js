const express = require('express');
const router = express.Router();
const Resume = require('../models/Resume');
const { auth } = require('../middleware/auth');

// @route   POST /api/resumes
// @desc    Create or update resume
router.post('/', auth, async (req, res) => {
  try {
    let resume = await Resume.findOne({ userId: req.user._id });

    if (resume) {
      // Update existing resume
      resume = await Resume.findOneAndUpdate(
        { userId: req.user._id },
        { $set: req.body },
        { new: true }
      );
    } else {
      // Create new resume
      resume = new Resume({
        userId: req.user._id,
        ...req.body
      });
      await resume.save();
    }

    res.json(resume);
  } catch (error) {
    console.error('Resume error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/resumes/:userId
// @desc    Get user's resume
router.get('/:userId', async (req, res) => {
  try {
    const resume = await Resume.findOne({ userId: req.params.userId })
      .populate('userId', 'name email');
    if (!resume) {
      return res.status(404).json({ message: 'Resume not found' });
    }
    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/resumes/:userId/download
// @desc    Download resume as HTML
router.get('/:userId/download', async (req, res) => {
  try {
    const resume = await Resume.findOne({ userId: req.params.userId })
      .populate('userId', 'name email');
    if (!resume) {
      return res.status(404).json({ message: 'Resume not found' });
    }

    const html = generateResumeHTML(resume);
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Disposition', `attachment; filename="resume-${resume.personalInfo.fullName || 'download'}.html"`);
    res.send(html);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

function generateResumeHTML(resume) {
  const { personalInfo, education, experience, skills, projects, certifications } = resume;
  
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${personalInfo.fullName || 'Resume'}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 40px 20px; }
    h1 { color: #1a1a2e; font-size: 28px; margin-bottom: 5px; }
    h2 { color: #16213e; font-size: 18px; border-bottom: 2px solid #0f3460; padding-bottom: 5px; margin: 20px 0 10px; text-transform: uppercase; letter-spacing: 1px; }
    h3 { color: #1a1a2e; font-size: 16px; margin-bottom: 3px; }
    .contact { color: #555; font-size: 14px; margin-bottom: 15px; }
    .contact span { margin-right: 15px; }
    .summary { color: #444; font-size: 14px; margin-bottom: 10px; }
    .item { margin-bottom: 15px; }
    .item-header { display: flex; justify-content: space-between; align-items: baseline; }
    .item-date { color: #666; font-size: 13px; font-style: italic; }
    .item-desc { color: #555; font-size: 14px; margin-top: 3px; }
    .skills-list { display: flex; flex-wrap: wrap; gap: 8px; }
    .skill-tag { background: #e8f0fe; color: #1a73e8; padding: 3px 12px; border-radius: 15px; font-size: 13px; }
    @media print { body { padding: 20px; } }
  </style>
</head>
<body>
  <h1>${personalInfo.fullName || ''}</h1>
  <div class="contact">
    ${personalInfo.email ? `<span>📧 ${personalInfo.email}</span>` : ''}
    ${personalInfo.phone ? `<span>📱 ${personalInfo.phone}</span>` : ''}
    ${personalInfo.address ? `<span>📍 ${personalInfo.address}</span>` : ''}
    ${personalInfo.linkedIn ? `<span>🔗 ${personalInfo.linkedIn}</span>` : ''}
  </div>
  ${personalInfo.summary ? `<p class="summary">${personalInfo.summary}</p>` : ''}

  ${education && education.length > 0 ? `
  <h2>Education</h2>
  ${education.map(edu => `
  <div class="item">
    <div class="item-header">
      <h3>${edu.degree} ${edu.fieldOfStudy ? `in ${edu.fieldOfStudy}` : ''}</h3>
      <span class="item-date">${edu.startYear || ''} - ${edu.endYear || 'Present'}</span>
    </div>
    <p class="item-desc">${edu.institution}${edu.grade ? ` | Grade: ${edu.grade}` : ''}</p>
  </div>`).join('')}` : ''}

  ${experience && experience.length > 0 ? `
  <h2>Experience</h2>
  ${experience.map(exp => `
  <div class="item">
    <div class="item-header">
      <h3>${exp.position} at ${exp.company}</h3>
      <span class="item-date">${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''}</span>
    </div>
    ${exp.description ? `<p class="item-desc">${exp.description}</p>` : ''}
  </div>`).join('')}` : ''}

  ${skills && skills.length > 0 ? `
  <h2>Skills</h2>
  <div class="skills-list">
    ${skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
  </div>` : ''}

  ${projects && projects.length > 0 ? `
  <h2>Projects</h2>
  ${projects.map(proj => `
  <div class="item">
    <h3>${proj.name}${proj.link ? ` <a href="${proj.link}" style="font-size:13px;color:#1a73e8;">↗</a>` : ''}</h3>
    ${proj.description ? `<p class="item-desc">${proj.description}</p>` : ''}
    ${proj.technologies ? `<p class="item-desc"><strong>Tech:</strong> ${proj.technologies}</p>` : ''}
  </div>`).join('')}` : ''}

  ${certifications && certifications.length > 0 ? `
  <h2>Certifications</h2>
  ${certifications.map(cert => `
  <div class="item">
    <h3>${cert.name}</h3>
    <p class="item-desc">${cert.issuer}${cert.year ? ` (${cert.year})` : ''}</p>
  </div>`).join('')}` : ''}
</body>
</html>`;
}

module.exports = router;
