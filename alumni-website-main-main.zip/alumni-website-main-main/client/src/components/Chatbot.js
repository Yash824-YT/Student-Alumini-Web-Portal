'use client';
import { useState } from 'react';

const FAQ_DATA = [
  {
    question: 'How do I update my profile?',
    answer: 'Navigate to the Alumni page, find your profile, and click on it to edit your details. You can update your name, department, bio, company, and more.'
  },
  {
    question: 'How do I apply for a job?',
    answer: 'Go to the Jobs page, browse available listings, and click "Apply Now" on any job that interests you. You must be logged in to apply.'
  },
  {
    question: 'How do I register for an event?',
    answer: 'Visit the Events page, find an event you\'d like to attend, and click "Register". You\'ll receive a confirmation once registered.'
  },
  {
    question: 'How do I create my resume?',
    answer: 'Click on "Resume" in the navigation bar. Fill in your personal info, education, experience, skills, and projects. You can then download it as an HTML file.'
  },
  {
    question: 'How do I search for alumni?',
    answer: 'Use the search bar on the Alumni page. You can search by name, department, company, or graduation year to find specific alumni.'
  },
  {
    question: 'Who can I contact for help?',
    answer: 'For technical issues, please reach out to the admin team through the contact form or email alumni.support@university.edu.'
  },
  {
    question: 'How do I become an admin?',
    answer: 'Admin access is granted by existing administrators. Contact the admin team if you need elevated permissions.'
  }
];

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { type: 'bot', text: '👋 Hi! I\'m the AlumniConnect assistant. How can I help you today? Click any question below or type your own!' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg = { type: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);

    // Simple keyword matching
    const lowerInput = input.toLowerCase();
    let answer = null;

    for (const faq of FAQ_DATA) {
      const keywords = faq.question.toLowerCase().split(' ').filter(w => w.length > 3);
      const matches = keywords.filter(kw => lowerInput.includes(kw));
      if (matches.length >= 2) {
        answer = faq.answer;
        break;
      }
    }

    if (!answer) {
      if (lowerInput.includes('hello') || lowerInput.includes('hi') || lowerInput.includes('hey')) {
        answer = '👋 Hello! How can I assist you today? Feel free to ask about profiles, jobs, events, or resumes!';
      } else if (lowerInput.includes('thank')) {
        answer = 'You\'re welcome! 😊 Is there anything else I can help with?';
      } else {
        answer = 'I\'m not sure about that. Here are some topics I can help with: profiles, jobs, events, resumes, and account settings. You can also click the quick questions below!';
      }
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { type: 'bot', text: answer }]);
    }, 500);

    setInput('');
  };

  const handleQuickQuestion = (faq) => {
    setMessages(prev => [
      ...prev,
      { type: 'user', text: faq.question },
      { type: 'bot', text: faq.answer }
    ]);
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full gradient-bg text-white shadow-lg shadow-indigo-500/30 flex items-center justify-center hover:scale-110 transition-transform"
        id="chatbot-toggle"
      >
        {isOpen ? (
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden slide-up" style={{ height: '520px' }}>
          {/* Header */}
          <div className="gradient-bg px-5 py-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-xl">🤖</span>
            </div>
            <div>
              <h3 className="text-white font-semibold text-[15px]">AlumniConnect Bot</h3>
              <p className="text-indigo-200 text-xs">Always here to help</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" id="chat-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-[14px] leading-relaxed ${
                  msg.type === 'user'
                    ? 'bg-indigo-500 text-white rounded-br-md'
                    : 'bg-slate-100 text-slate-700 rounded-bl-md'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          {/* Quick Questions */}
          <div className="px-4 pb-2 flex gap-2 overflow-x-auto scrollbar-none">
            {FAQ_DATA.slice(0, 3).map((faq, i) => (
              <button
                key={i}
                onClick={() => handleQuickQuestion(faq)}
                className="shrink-0 text-xs px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-full hover:bg-indigo-100 transition-colors whitespace-nowrap"
              >
                {faq.question.length > 25 ? faq.question.slice(0, 25) + '...' : faq.question}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="px-4 py-3 border-t border-slate-100">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your question..."
                className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-400 focus:bg-white transition-all"
                id="chatbot-input"
              />
              <button
                onClick={handleSend}
                className="w-10 h-10 rounded-xl gradient-bg text-white flex items-center justify-center hover:opacity-90 transition-opacity shrink-0"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
